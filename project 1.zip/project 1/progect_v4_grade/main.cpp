/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototype

//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
      srand(static_cast<unsigned int>(time(0)));// seed time to a random number determined by seconds passed since jan 1 1970
    //Declare Variable Data Types and Constants
    const unsigned int chance = 1/(pow(6,5));// chances of rolling a yahtzee on first try  
    const unsigned short turns = 13; // number of turns in yahtzee  
    int j = 0;// start the game with zero turns played
    string yaht;  // ask the player if they recived yahtzee
    bool yahtzee;// determines if player got a yahtzee
    char answer;// answer to if you wna t to run the game again
    unsigned short diceA, diceB, diceC, diceD, diceE ; // dive dice used in a game of yahtzee
    char roll;// determine if they want to re-roll
    //Initialize Variables
    while( j < turns && (answer != 'n' || answer != 'n') ){// stop when the number of turns in yahtzee has been reached or player wishes to stop playing
        do{// start of game 
            diceA = (rand()%6+1);// set the dice roll to a random number 1-6
            diceB = (rand()%6+1);
            diceC = (rand()%6+1);
            diceD = (rand()%6+1);
            diceE = (rand()%6+1);

        //Process or map Inputs to Outputs

        //Display Outputs
            cout << "dice1" << setw(7) << "dice2" << setw(7) << "dice3" << setw(7) << "dice4" << setw(7) << "dice5" << endl;// making dice
            cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" <<  endl;
            cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
            cout << "|" << setw(2) << diceA << setw(2)  << "|" << setw(2);
            cout << "|" << setw(2) << diceB << setw(3)  << "|" << setw(2);
            cout << "|" << setw(2) << diceC << setw(3)  << "|" << setw(3);
            cout << "|" << setw(2) << diceD << setw(2)  << "|" << setw(3);
            cout << "|" << setw(2) << diceE << setw(2)  << "|" << setw(2) << endl;
            cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
            cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----"  << endl;
           // ask the user if they got yahtzee
             if (diceA == diceB && diceB == diceC && diceD == diceC && diceE ==diceD ){// determine if yahtzee was rolled
                yahtzee = true;
             }
             else 
                 yahtzee = false;
             
            cout << "Enter yahtzee if all six numbers are the same or no if they are not" << endl;// ask user if they rolled yahtzee
            cin >> yaht;
            if (yaht == "yahtzee" && yahtzee){// determine if user told the truth
                cout << "congrats the chance of rolling a yahtzee on your first time is" << chance << endl;// output chance of rolling yahtzee
                
            }
           

            

        // chose if you want to re roll any of the dice up to three
            cout << "Do you want to re-roll any dice enter y or n" << endl;// determine if player wants any re-rolls
            cin >> roll;


            if(roll == 'y'|| roll == 'Y'){// reroll dice
                for (int i = 0; i<2; i++){//loop to run re-roll up to 3 times if the user wants
                unsigned short dice1, dice2, dice3, dice4, dice5;  // dice to re-roll
                char numdice;// number of dice to reroll
                cout << "enter the number of dice you want to re-roll \n";
                cin >> numdice;
                    switch(numdice){
                        case '0':i = 3;break;// person is done rolling
                        case '1':{//person wants to re-roll one
                            cout << "enter the number of the dice you wish to re-roll\n";
                            cin >> dice1;
                            if (dice1 == 1){// input new value into dice
                                dice1 =rand()%6+1; 
                                diceA = dice1;
                            }
                            else if(dice1 == 2){
                                dice1 =rand()%6+1; 
                                diceB =dice1;
                            }
                            else if(dice1 == 3){
                                dice1 =rand()%6+1; 
                                diceC =dice1;
                            }
                            else if(dice1 == 4){
                                dice1 =rand()%6+1; 
                                diceD =dice1;
                            }
                            else{ 
                                dice1 =rand()%6+1; 
                                diceE = dice1;
                            }
                                //Display Outputs
                             cout << "dice1" << setw(7) << "dice2" << setw(7) << "dice3" << setw(7) << "dice4" << setw(7) << "dice5" << endl;// show the new dice roll
                             cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" <<  endl;
                             cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
                             cout << "|" << setw(2) << diceA << setw(2)  << "|" << setw(2);
                             cout << "|" << setw(2) << diceB << setw(3)  << "|" << setw(2);
                             cout << "|" << setw(2) << diceC << setw(3)  << "|" << setw(3);
                             cout << "|" << setw(2) << diceD << setw(2)  << "|" << setw(3);
                             cout << "|" << setw(2) << diceE << setw(2)  << "|" << setw(2) << endl;
                             cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
                             cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----"  << endl;

                            break;
                        }
                        case '2':{//person wants to re-roll two dice

                            cout << "enter the number of the dice you wish to re-roll\n";
                            cin >> dice1 >> dice2;
                            if (dice1 == 1){// input new value into dice 1
                                dice1 =rand()%6+1; 
                                diceA = dice1;
                            }
                            else if(dice1 == 2){
                                dice1 =rand()%6+1; 
                                diceB =dice1;
                            }
                            else if(dice1 == 3){
                                dice1 =rand()%6+1; 
                                diceC =dice1;
                            }
                            else if(dice1 == 4){
                                dice1 =rand()%6+1; 
                                diceD =dice1;
                            }
                            else{ 
                                dice1 =rand()%6+1; 
                                diceE = dice1;
                            }
                            if (dice2 == 1){// input new value into dice 2
                                dice2 =rand()%6+1; 
                                diceA = dice2;
                            }
                            else if(dice2 == 2){
                                dice2 =rand()%6+1; 
                                diceB =dice2;
                            }
                            else if(dice2 == 3){
                                dice2 =rand()%6+1; 
                                diceC =dice2;
                            }
                            else if(dice2 == 4){
                                dice2 =rand()%6+1; 
                                diceD =dice2;
                            }
                            else{ 
                                dice2 =rand()%6+1; 
                                diceE = dice2;
                            }
                             cout << "dice1" << setw(7) << "dice2" << setw(7) << "dice3" << setw(7) << "dice4" << setw(7) << "dice5" << endl;// show the new dice roll
                             cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" <<  endl;
                             cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
                             cout << "|" << setw(2) << diceA << setw(2)  << "|" << setw(2);
                             cout << "|" << setw(2) << diceB << setw(3)  << "|" << setw(2);
                             cout << "|" << setw(2) << diceC << setw(3)  << "|" << setw(3);
                             cout << "|" << setw(2) << diceD << setw(2)  << "|" << setw(3);
                             cout << "|" << setw(2) << diceE << setw(2)  << "|" << setw(2) << endl;
                             cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
                             cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----"  << endl;
                             break;
                        }
                            case'3':{// player wants to reroll 3 dice
                                cout << "enter the number of the dice you wish to re-roll\n";
                            cin >> dice1 >> dice2 >> dice3;
                            if (dice1 == 1){// input new value into dice 1
                                dice1 =rand()%6+1; 
                                diceA = dice1;
                            }
                            else if(dice1 == 2){
                                dice1 =rand()%6+1; 
                                diceB =dice1;
                            }
                            else if(dice1 == 3){
                                dice1 =rand()%6+1; 
                                diceC =dice1;
                            }
                            else if(dice1 == 4){
                                dice1 =rand()%6+1; 
                                diceD =dice1;
                            }
                            else{ 
                                dice1 =rand()%6+1; 
                                diceE = dice1;
                            }
                            if (dice2 == 1){// input new value into dice 2
                                dice2 =rand()%6+1; 
                                diceA = dice2;
                            }
                            else if(dice2 == 2){
                                dice2 =rand()%6+1; 
                                diceB =dice2;
                            }
                            else if(dice2 == 3){
                                dice2 =rand()%6+1; 
                                diceC =dice2;
                            }
                            else if(dice2 == 4){
                                dice2 =rand()%6+1; 
                                diceD =dice2;
                            }
                            else{ 
                                dice2 =rand()%6+1; 
                                diceE = dice2;
                            }
                            if (dice3 == 1){// input new value into dice 3
                                dice3 =rand()%6+1; 
                                diceA = dice3;
                            }
                            else if(dice3 == 2){
                                dice3 =rand()%6+1; 
                                diceB =dice3;
                            }
                            else if(dice3 == 3){
                                dice3 =rand()%6+1; 
                                diceC =dice3;
                            }
                            else if(dice3 == 4){
                                dice3 =rand()%6+1; 
                                diceD =dice3;
                            }
                            else{ 
                                dice3 =rand()%6+1; 
                                diceE = dice3;
                            }
                             cout << "dice1" << setw(7) << "dice2" << setw(7) << "dice3" << setw(7) << "dice4" << setw(7) << "dice5" << endl;// show the new dice roll
                             cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" <<  endl;
                             cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
                             cout << "|" << setw(2) << diceA << setw(2)  << "|" << setw(2);
                             cout << "|" << setw(2) << diceB << setw(3)  << "|" << setw(2);
                             cout << "|" << setw(2) << diceC << setw(3)  << "|" << setw(3);
                             cout << "|" << setw(2) << diceD << setw(2)  << "|" << setw(3);
                             cout << "|" << setw(2) << diceE << setw(2)  << "|" << setw(2) << endl;
                             cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
                             cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----"  << endl;
                             break;

                        }
                        case'4':{
                            cout << "enter the number of the dice you wish to re-roll\n";
                            cin >> dice1 >> dice2 >> dice3 >> dice4;
                            if (dice1 == 1){// input new value into dice 1
                                dice1 =rand()%6+1; 
                                diceA = dice1;
                            }
                            else if(dice1 == 2){
                                dice1 =rand()%6+1; 
                                diceB =dice1;
                            }
                            else if(dice1 == 3){
                                dice1 =rand()%6+1; 
                                diceC =dice1;
                            }
                            else if(dice1 == 4){
                                dice1 =rand()%6+1; 
                                diceD =dice1;
                            }
                            else{ 
                                dice1 =rand()%6+1; 
                                diceE = dice1;
                            }
                            if (dice2 == 1){// input new value into dice 2
                                dice2 =rand()%6+1; 
                                diceA = dice2;
                            }
                            else if(dice2 == 2){
                                dice2 =rand()%6+1; 
                                diceB =dice2;
                            }
                            else if(dice2 == 3){
                                dice2 =rand()%6+1; 
                                diceC =dice2;
                            }
                            else if(dice2 == 4){
                                dice2 =rand()%6+1; 
                                diceD =dice2;
                            }
                            else{ 
                                dice2 =rand()%6+1; 
                                diceE = dice2;
                            }
                            if (dice3 == 1){// input new value into dice 3
                                dice3 =rand()%6+1; 
                                diceA = dice3;
                            }
                            else if(dice3 == 2){
                                dice3 =rand()%6+1; 
                                diceB =dice3;
                            }
                            else if(dice3 == 3){
                                dice3 =rand()%6+1; 
                                diceC =dice3;
                            }
                            else if(dice3 == 4){
                                dice3 =rand()%6+1; 
                                diceD =dice3;
                            }
                            else{ 
                                dice3 =rand()%6+1; 
                                diceE = dice3;
                            }
                            if (dice4 == 1){// input new value into dice 4
                                dice4 =rand()%6+1; 
                                diceA = dice4;
                            }
                            else if(dice4 == 2){
                                dice4 =rand()%6+1; 
                                diceB =dice4;
                            }
                            else if(dice4 == 3){
                                dice4 =rand()%6+1; 
                                diceC =dice4;
                            }
                            else if(dice4 == 4){
                                dice4 =rand()%6+1; 
                                diceD =dice4;
                            }
                            else{ 
                                dice4 =rand()%6+1; 
                                diceE = dice4;
                            }
                             cout << "dice1" << setw(7) << "dice2" << setw(7) << "dice3" << setw(7) << "dice4" << setw(7) << "dice5" << endl;// show the new dice roll
                             cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" <<  endl;
                             cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
                             cout << "|" << setw(2) << diceA << setw(2)  << "|" << setw(2);
                             cout << "|" << setw(2) << diceB << setw(3)  << "|" << setw(2);
                             cout << "|" << setw(2) << diceC << setw(3)  << "|" << setw(3);
                             cout << "|" << setw(2) << diceD << setw(2)  << "|" << setw(3);
                             cout << "|" << setw(2) << diceE << setw(2)  << "|" << setw(2) << endl;
                             cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
                             cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----"  << endl;
                             break;
                        }
                        case'5':{// player wants to re-roll all dice
                            diceA = (rand()%6+1);// set the dice roll to a random number 1-6
                            diceB = (rand()%6+1);
                            diceC = (rand()%6+1);
                            diceD = (rand()%6+1);
                            diceE = (rand()%6+1);
                             cout << "dice1" << setw(7) << "dice2" << setw(7) << "dice3" << setw(7) << "dice4" << setw(7) << "dice5" << endl;// show the new dice roll
                             cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" <<  endl;
                             cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
                             cout << "|" << setw(2) << diceA << setw(2)  << "|" << setw(2);
                             cout << "|" << setw(2) << diceB << setw(3)  << "|" << setw(2);
                             cout << "|" << setw(2) << diceC << setw(3)  << "|" << setw(3);
                             cout << "|" << setw(2) << diceD << setw(2)  << "|" << setw(3);
                             cout << "|" << setw(2) << diceE << setw(2)  << "|" << setw(2) << endl;
                             cout << "|   |" << setw(7) << "|    |" << setw(7) << "|    |" << setw(7) << "|   |" << setw(7) << "|   |"  << endl;
                             cout << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----" << setw(7) << "-----"  << endl;
                             break;
                             
                        }


                    }

                }


            }


            cout << " Enter y if you wish to continue the game and n if you do not.\n";// determine if you should re run the loop or not
            cin >> answer;
        }  while(answer != 'N' && answer !='n');
    j++;}// total number of turns taken
    //Exit stage right!
    return 0;
}