/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes
void compare(char answer[], char array[], int &correct, int &wrong);// compares the answers to see how many were correct
void question(char answer[], char array[]);
//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    const unsigned short size = 20;
    char answer[20];// array to hold variables
    char correct[20] = {'A', 'D', 'B', 'B', 'C', 'B', 'A', 'B', 'C', 'D', 'A', 'C', 'D', 'B', 'D', 'C', 'C', 'A', 'D', 'B'};
    int right, wrong;// hold the number of right and wrong variables
    unsigned short score = 0;
    //Initialize Variables
    cout << "Enter the student's test answers:\n";
    for (int i = 0; i < size; i ++){
        cin >> answer[i];
    }
    
    //Process or map Inputs to Outputs
  compare(answer, correct, right, wrong);
  if(right >=15)
  cout << "The student passed." << endl;
    //Display Outputs
   cout << "There were " << right << " correct answers." << endl; 
   cout << "There were " << wrong << " incorrect answers." << endl;
   cout << "Incorrect questions:" << endl;
   question(answer, correct);
    //Exit stage right!
    return 0;
}
void compare(char answer[], char array[], int &correct, int &wrong){
    correct = 0;
    wrong = 0;
    for (int i = 0; i < 20; i ++){
        
        if (answer[i] == array[i])
        correct++;
        else
        wrong++;
        }
}
void question(char answer[], char array[]){
    int missed[20];
    int count = 0;
    for (int i = 0; i < 20; i ++){
    
        if (answer[i] != array[i]){
           missed[count] = i + 1;
           cout << missed[count] <<endl;
            count++;
           
           
        }
        
    }
}
 