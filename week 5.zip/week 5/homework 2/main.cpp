/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes
void total(float array[], int size);// make a total of a array
void best(float array[], string arrays[], int size);// find best selling salsa
void worst(float array[], string arrays[], int size);// find worst selling salsa
//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    const unsigned short size = 5;// size of parellel arrays
    string salsa[5] = {"mild", "medium", "sweet", "hot", "zesty"};// name of the five salsa
    float price[5];// price of each salsa
    //Initialize Variables
    cout << "Enter the sales of mild salsa:$\n";
    cin >> price[0];
    cout << "Enter the sales of medium salsa:$\n";
    cin >> price[1];
    cout << "Enter the sales of sweet salsa:$\n";
    cin >> price[2];
    cout << "Enter the sales of hot salsa:$\n";
    cin >> price[3];
    cout << "Enter the sales of zesty salsa:$\n";
    cin >> price[4];
    //Process or map Inputs to Outputs
    cout << "Type" <<setw(10) << "Sales" << endl;
    //Display Outputs
for (int i=0; i < size; i ++){
    cout << left << setw(9) <<salsa[i]  << "$" << price[i]  << endl;
}
total(price, size);
worst(price, salsa, size);
best(price, salsa, size);
    //Exit stage right!
    return 0;
}
void total(float array[], int size){// make a total of a array
    float temp = 0;
    for (int i =0; i < size; i++){
    temp =  array[i] + temp ;
    }
    cout << "Total Sales was $" << temp << endl;
}
void best(float array[], string arrays[], int size){// find best selling salsa
    int temp = array[0];
    string temps;// temporary string
    for (int i = 0; i < size; i ++){
        if (array[i] >= temp){
        temp = array[i];
        temps = arrays[i];
        }
    }
    cout << temps << " was the highest selling product.";
}
void worst(float array[], string arrays[], int size){// find worst selling salsa
    int temp = array[0];
    string temps;// temporary string
    for (int i = 0; i < size; i ++){
        if (array[i] <= temp){
        temp = array[i];
        temps = arrays[i];
        }
    }
    cout << temps << " was the lowest selling product." << endl;

}