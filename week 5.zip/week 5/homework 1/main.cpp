/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - No Global Variables
//Only Universal Constants, Math, Physics, Conversions, Higher Dimensions

//Function Prototypes
void max(int array[], int value);
void min(int array[], int value);
//Execution Begins Here
int main(int argc, char** argv) {
    //Set Random Number seed
    
    //Declare Variable Data Types and Constants
    const unsigned short value = 10;// the number of values being put into the program
    int num[10];// 10 numbers the user input
    int temp;// temporary value
    //Initialize Variables
    cout << "Enter 10 integers:\n";
    //Process or map Inputs to Outputs
for (int i = 0; i < value; i ++){
    cin >> temp;
    num[i] = temp; 
}
 max(num, value);
    //Display Outputs
    cout <<" is the highest number.\n";
min(num, value);
    cout << " is the lowest number.";
    //Exit stage right!
    return 0;
}
void max(int array[], int value){// find maximum value
    int temp = array[1];
    for (int i = 0; i < value; i ++){
        if (array[i] > temp)
        temp = array[i];
}
    cout << temp; 
}
void min(int array[], int value){// find minumum value
    int temp = array[1];
    for (int i = 0; i < value; i ++){
        if (array[i] < temp)
        temp = array[i];
}
    cout << temp; 
}