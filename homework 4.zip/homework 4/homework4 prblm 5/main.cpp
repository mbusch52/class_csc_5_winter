/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    unsigned short num;//biggest number of +
    unsigned short i, n;// number of iterations
    unsigned short temp, temp2;//temporay variable
    //Initialize or input i.e. set variable values
    cin >> num;
    temp = num;
    temp2 = temp - 1;
    n = 0;
    //Map inputs -> outputs
    for(i = num; i > 0; i--){
        
        while (n < temp - temp2){
            cout << "+";
            n++;
        }
        n=0;
        temp ++;
       cout << endl << endl;
    }
    temp = num;
    n = 0;
    for (i = num; i >1; i--){
        while (n < temp ){
        cout << "+";
        n++;
        }
        n = 1;
        temp--;
        cout << endl << endl;
        cout << "+";
    }
    //Display the outputs

    //Exit stage right or left!
    return 0;
}