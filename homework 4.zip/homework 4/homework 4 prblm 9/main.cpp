/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float cprice, oprice, irate, year1, year2;// current price, old price, intrest irate
    char answr;
    //Initialize or input i.e. set variable values
    cout << "Enter current price:" << endl;
    cin >> cprice;
    cout << "Enter year-ago price:" << endl;
    cin >> oprice;
    cout << fixed << setprecision(2);
    irate = ((cprice - oprice)/oprice)*100;
    cout << "Inflation rate: " << irate << "%" << endl << endl;
    year1 = cprice * (irate/100) + cprice;
    year2 = cprice * (irate/100) + year1;
    cout << "Price in one years: " << year1 << endl;
    cout << "Price in two years: " << year2 << endl;
    cout << "Again:" << endl << endl;
    cin >> answr;
    do{
    cout << "Enter current price:" << endl;
    cin >> cprice;
    cout << "Enter year-ago price:" << endl;
    cin >> oprice;
    cout << fixed << setprecision(2);
    irate = ((cprice - oprice)/oprice)*100;
    cout << "Inflation rate: " << irate << "%" << endl << endl;
    cout << "Again:" << endl;
    cin >> answr;
}
while (answr =='Y' || answr == 'y');
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}