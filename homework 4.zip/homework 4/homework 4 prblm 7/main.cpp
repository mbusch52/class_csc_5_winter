/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
float littogal = 1.0f/.264179f;
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float gas, mpg, miles, gas2, mpg2, miles2;
    char answr;
    //Initialize or input i.e. set variable values
    cout << "Car 1" << endl;
    cout << "Enter number of liters of gasoline:" << endl ;
    cin >> miles;
    
    cout << "Enter number of miles traveled:" << endl ;
    cin >> gas;
    gas = gas * littogal;
    cout << "miles per gallon:" ;
    
    //Map inputs -> outputs
    mpg = gas / miles;
    //Display the outputs
    cout << " " << fixed << setprecision(2) << mpg << endl << endl;
        cout << "Car 2" << endl;
    cout << "Enter number of liters of gasoline:" << endl ;
    cin >> miles2;
    
    cout << "Enter number of miles traveled:" << endl ;
    cin >> gas2;
    gas2 = gas2 * littogal;
    cout << "miles per gallon:" ;
    
    //Map inputs -> outputs
    mpg2 = gas2 / miles2;
    //Display the outputs
    cout << " " << fixed << setprecision(2) << mpg2 << endl << endl;
   
    if (mpg > mpg2){
    cout << "Car 1 is more fuel efficient" << endl;
    }
    else{ 
    cout << "Car 2 is more fuel efficient" << endl;
    }
    cout << endl;
    cout << "Again:" << endl << endl;
    cin >> answr;
   do{ cout << "Car 1" << endl;
    cout << "Enter number of liters of gasoline:" << endl ;
    cin >> miles;
    
    cout << "Enter number of miles traveled:" << endl ;
    cin >> gas;
    gas = gas * littogal;
    cout << "miles per gallon:" ;
    
    //Map inputs -> outputs
    mpg = gas / miles;
    //Display the outputs
    cout << " " << fixed << setprecision(2) << mpg << endl << endl;
        cout << "Car 2" << endl;
    cout << "Enter number of liters of gasoline:" << endl ;
    cin >> miles2;
    
    cout << "Enter number of miles traveled:" << endl ;
    cin >> gas2;
    gas2 = gas2 * littogal;
    cout << "miles per gallon:" ;
    
    //Map inputs -> outputs
    mpg2 = gas2 / miles2;
    //Display the outputs
    cout << " " << fixed << setprecision(2) << mpg2 << endl << endl;
   
    if (mpg > mpg2){
    cout << "Car 1 is more fuel efficient" << endl;
    }
    else{ 
    cout << "Car 2 is more fuel efficient" << endl;
    }
    cout << endl;
    cout << "Again:" << endl;
    cin >> answr; 
   }
   while (answr == 'Y' || answr == 'y');
    return 0;
}