/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: busch
 *
 * Created on January 23, 2021, 9:21 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */float littogal = 1.0f/.264179f;
int main(int argc, char** argv) {
    char answr;
    cout << "menu program for homework 4" << endl;
    cout << "enter 1 for sum program" << endl;
    cout << "enter 2 for pennie program" << endl;
    cout << "enter 3 for num sorting program" << endl;
    cout << "enter 4 for rectangle program" << endl;
    cout << "enter 5 for + program" << endl;
    cout << "enter 6 for mpg program" << endl;
    cout << "enter 7 for mpg comparison program" << endl;
    cout << "enter 8 for inflation calculator program" << endl;
    cout << "enter 9 for 2 year inflation program" << endl;
    cin >> answr;
    if (answr == 1){
          //Set the random number seed
    
    //Declare Variables
    unsigned short number, sum;
    //Initialize or input i.e. set variable values
    cin >> number;
    for (int i=1; i <= number; i++){
    sum = i+sum;
    }
    cout << sum;
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    }
    else if (answr == 2){
         //Declare Variables
    unsigned short days, i; 
    float pennies, ttl;
    //Initialize or input i.e. set variable values
    cin >> days;
    ttl = 0;
    pennies = 0.01;
    if (days >=1){
    for (i=1; i<=days ; i++){
        
        ttl =  pennies + ttl;
        pennies = pennies * 2;
    }
    cout << "Pay = $" << ttl;
    }
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    else if (answr == 3){
         //Declare Variables
    short num, small, large;
    cin >> num;
    small = num;
    large = num;
    while (num !=-99){
    if (num >= large)
    large = num;
    if (num <= small)
    small = num;
    cin >> num;
    }
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cout << "Smallest number in the series is " << small;
    cout << "Largest  number in the seies is " << large;
    //Display the outputs

    //Exit stage right or left!
    }
    }
    else if (answr == 4){
         //Declare Variables
    unsigned short num, i, n, end;
    char letter;
    //Initialize or input i.e. set variable values
    end = 0;
    cin >> num >> letter;
    //Map inputs -> outputs
    for (n = 1; n < num; n++){
        for (i = 0; i < num; i++){
        cout << letter;
        }
    cout << endl;
    }
    while(end < num){
    cout << letter;
    end = end +1;
    }
    //Display the outputs
    }
    else if (answr == 5){
          //Declare Variables
    unsigned short num;//biggest number of +
    unsigned short i, n;// number of iterations
    unsigned short temp, temp2;//temporay variable
    //Initialize or input i.e. set variable values
    cin >> num;
    temp = num;
    temp2 = temp - 1;
    n = 0;
    //Map inputs -> outputs
    for(i = num; i > 0; i--){
        
        while (n < temp - temp2){
            cout << "+";
            n++;
        }
        n=0;
        temp ++;
       cout << endl << endl;
    }
    temp = num;
    n = 0;
    for (i = num; i >1; i--){
        while (n < temp ){
        cout << "+";
        n++;
        }
        n = 1;
        temp--;
        cout << endl << endl;
        cout << "+";
    }
    //Display the outputs

    }
    else if (answr == 6){
          //Declare Variables
    float gas, mpg, miles;
    char answr;
    //Initialize or input i.e. set variable values
    cout << "Enter number of liters of gasoline:" << endl << endl;
    cin >> miles;
    
    cout << "Enter number of miles traveled:" << endl << endl;
    cin >> gas;
    gas = gas * littogal;
    cout << "miles per gallon:" << endl;
    
    //Map inputs -> outputs
    mpg = gas / miles;
    //Display the outputs
    cout << fixed << setprecision(2) << mpg << endl;
    cout << "Again:" << endl << endl;
    cin >> answr;
   do{ 
   cout << "Enter number of liters of gasoline:" << endl << endl;
    cin >> miles;
    
    cout << "Enter number of miles traveled:" << endl << endl;
    cin >> gas;
    gas = gas * littogal;
    cout << "miles per gallon:" << endl;
    
    //Map inputs -> outputs
    mpg = gas / miles;
    //Display the outputs
    cout << fixed << setprecision(2) << mpg << endl;
    cout << "Again:" << endl;
    cin >> answr;
   }
   while (answr == 'Y' || answr == 'y');
   
    //Exit stage right or left!
    }
    else if (answr == 7){
          //Declare Variables
    float gas, mpg, miles, gas2, mpg2, miles2;
    char answr;
    //Initialize or input i.e. set variable values
    cout << "Car 1" << endl;
    cout << "Enter number of liters of gasoline:" << endl ;
    cin >> miles;
    
    cout << "Enter number of miles traveled:" << endl ;
    cin >> gas;
    gas = gas * littogal;
    cout << "miles per gallon:" ;
    
    //Map inputs -> outputs
    mpg = gas / miles;
    //Display the outputs
    cout << " " << fixed << setprecision(2) << mpg << endl << endl;
        cout << "Car 2" << endl;
    cout << "Enter number of liters of gasoline:" << endl ;
    cin >> miles2;
    
    cout << "Enter number of miles traveled:" << endl ;
    cin >> gas2;
    gas2 = gas2 * littogal;
    cout << "miles per gallon:" ;
    
    //Map inputs -> outputs
    mpg2 = gas2 / miles2;
    //Display the outputs
    cout << " " << fixed << setprecision(2) << mpg2 << endl << endl;
   
    if (mpg > mpg2){
    cout << "Car 1 is more fuel efficient" << endl;
    }
    else{ 
    cout << "Car 2 is more fuel efficient" << endl;
    }
    cout << endl;
    cout << "Again:" << endl << endl;
    cin >> answr;
   do{ cout << "Car 1" << endl;
    cout << "Enter number of liters of gasoline:" << endl ;
    cin >> miles;
    
    cout << "Enter number of miles traveled:" << endl ;
    cin >> gas;
    gas = gas * littogal;
    cout << "miles per gallon:" ;
    
    //Map inputs -> outputs
    mpg = gas / miles;
    //Display the outputs
    cout << " " << fixed << setprecision(2) << mpg << endl << endl;
        cout << "Car 2" << endl;
    cout << "Enter number of liters of gasoline:" << endl ;
    cin >> miles2;
    
    cout << "Enter number of miles traveled:" << endl ;
    cin >> gas2;
    gas2 = gas2 * littogal;
    cout << "miles per gallon:" ;
    
    //Map inputs -> outputs
    mpg2 = gas2 / miles2;
    //Display the outputs
    cout << " " << fixed << setprecision(2) << mpg2 << endl << endl;
   
    if (mpg > mpg2){
    cout << "Car 1 is more fuel efficient" << endl;
    }
    else{ 
    cout << "Car 2 is more fuel efficient" << endl;
    }
    cout << endl;
    cout << "Again:" << endl;
    cin >> answr; 
   }
   while (answr == 'Y' || answr == 'y');
    }
    else if (answr == 8){
        //Declare Variables
    float cprice, oprice, irate;// current price, old price, intrest irate
    char answr;
    //Initialize or input i.e. set variable values
    cout << "Enter current price:" << endl;
    cin >> cprice;
    cout << "Enter year-ago price:" << endl;
    cin >> oprice;
    cout << fixed << setprecision(2);
    irate = ((cprice - oprice)/oprice)*100;
    cout << "Inflation rate: " << irate << "%" << endl << endl;
    cout << "Again:" << endl << endl;
    cin >> answr;
    do{
    cout << "Enter current price:" << endl;
    cin >> cprice;
    cout << "Enter year-ago price:" << endl;
    cin >> oprice;
    cout << fixed << setprecision(2);
    irate = ((cprice - oprice)/oprice)*100;
    cout << "Inflation rate: " << irate << "%" << endl << endl;
    cout << "Again:" << endl;
    cin >> answr;
}
while (answr =='Y' || answr == 'y');
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    }
    else if (answr == 9){
          //Declare Variables
    float cprice, oprice, irate, year1, year2;// current price, old price, intrest irate
    char answr;
    //Initialize or input i.e. set variable values
    cout << "Enter current price:" << endl;
    cin >> cprice;
    cout << "Enter year-ago price:" << endl;
    cin >> oprice;
    cout << fixed << setprecision(2);
    irate = ((cprice - oprice)/oprice)*100;
    cout << "Inflation rate: " << irate << "%" << endl << endl;
    year1 = cprice * (irate/100) + cprice;
    year2 = cprice * (irate/100) + year1;
    cout << "Price in one years: " << year1 << endl;
    cout << "Price in two years: " << year2 << endl;
    cout << "Again:" << endl << endl;
    cin >> answr;
    do{
    cout << "Enter current price:" << endl;
    cin >> cprice;
    cout << "Enter year-ago price:" << endl;
    cin >> oprice;
    cout << fixed << setprecision(2);
    irate = ((cprice - oprice)/oprice)*100;
    cout << "Inflation rate: " << irate << "%" << endl << endl;
    cout << "Again:" << endl;
    cin >> answr;
}
while (answr =='Y' || answr == 'y');
    
    }
    return 0;
}

