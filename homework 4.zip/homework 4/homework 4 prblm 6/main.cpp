/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
float littogal = 1.0f/.264179f;
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float gas, mpg, miles;
    char answr;
    //Initialize or input i.e. set variable values
    cout << "Enter number of liters of gasoline:" << endl << endl;
    cin >> miles;
    
    cout << "Enter number of miles traveled:" << endl << endl;
    cin >> gas;
    gas = gas * littogal;
    cout << "miles per gallon:" << endl;
    
    //Map inputs -> outputs
    mpg = gas / miles;
    //Display the outputs
    cout << fixed << setprecision(2) << mpg << endl;
    cout << "Again:" << endl << endl;
    cin >> answr;
   do{ 
   cout << "Enter number of liters of gasoline:" << endl << endl;
    cin >> miles;
    
    cout << "Enter number of miles traveled:" << endl << endl;
    cin >> gas;
    gas = gas * littogal;
    cout << "miles per gallon:" << endl;
    
    //Map inputs -> outputs
    mpg = gas / miles;
    //Display the outputs
    cout << fixed << setprecision(2) << mpg << endl;
    cout << "Again:" << endl;
    cin >> answr;
   }
   while (answr == 'Y' || answr == 'y');
   
    //Exit stage right or left!
    return 0;
}