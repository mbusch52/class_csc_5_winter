/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on March 17th, 2020, 11:33 AM
 * Purpose: Menu to be utilized in Homework
 */

//System Level Libraries
#include <iostream> 
#include <iomanip>
#include <string>//I/O Library
using namespace std;  //Libraries compiled under std

//User Level Libraries

//Global Constants - Science/Math Related
//Conversions, Higher Dimensions

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Variable Declarations
    char choice;

    //Display Menu
    cout<<"Menu Example for Homework"<<endl;
    cout<<"Type 1 for name sorting"<<endl;
    cout<<"Type 2 for book problem"<<endl;
    cout<<"Type 3 for bank problem"<<endl;
    cout<<"Type 4 for race problem"<<endl;
    cout<<"Type 5 for ISPproblem"<<endl;
    cout<<"Type 6 for rock paper scissors problem"<<endl;
    cout<<"Type 7 for roman numeral problem"<<endl;
    cout<<"Type 8 for sign problem"<<endl;
    cin>>choice;
    
    if(choice=='1'){
         string name1, name2, name3; //name being input
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cout << "Sorting Names" << endl;
    cout << "Input 3 names" << endl;
    cin >> name1;
    cin >> name2;
    cin >> name3;
    if (name1 > name2 && name2 > name3){
    cout << name3 << endl << name2 << endl << name1;
    }
    else if (name1 > name2 && name3 > name2){
    cout << name2 << endl << name3 << endl << name1;
    }
    else if (name2 > name1 && name1 > name3){
    cout << name3 << endl << name1 << endl << name2;
    }
    else if (name2 > name1 && name3 > name1){
    cout << name1 << endl << name3 << endl << name2;
    }
    else if (name3 > name2 && name3 > name1){
    cout << name1 << endl << name2 << endl << name3;
    }
    else if (name3 > name2 && name1 > name2){
    cout << name2 << endl << name1 << endl << name3;
    }
    }else if(choice=='2'){
         char numbook;
    unsigned short points;
    //Initialize or input i.e. set variable values
    cout<<"Book Worm Points\n";
    cout<<"Input the number of books purchased this month.\n";
    cin>>numbook;
   
    if (numbook>=4){
        points = 60;
    }
    else if (numbook==3){
        points = 30;
    }
    else if (numbook==2){
        points = 15;
    }
    else if (numbook==1){
        points = 5;
    }
    else if (numbook<=0){
        points = 0;
    }
    else 
    cout << "you entered an incorrect number";
    cout<< left << setw(16) << "Books purchased" << "="<< right << setw(3) << numbook << endl;
    cout<< left << setw(16) << "Points earned"  << "="<< right << setw(3) <<points;
    }else if(choice=='3'){
            float sbalance, balance, numcheck, nbalance, checks, monthly, low;
    cout<<"Monthly Bank Fees\n";
    cout<<"Input Current Bank Balance and Number of Checks\n";
    cin>>balance;
    cin>>checks;
    sbalance = balance;
    monthly = 10;
    if(balance<400){
        balance = balance-15;
        low = 15.0f;
    }
    if (checks < 20){
        numcheck = (.10 * checks);
        nbalance = balance - numcheck -10;
    }
    else if (checks < 40){
        numcheck = (.08 * checks);
        nbalance = balance - numcheck -10;
    }
     else if (checks < 60){
        numcheck = (.06 * checks);
        nbalance = balance - numcheck -10;
    }
     else
     numcheck =  (.04 * checks);
        nbalance = balance - numcheck -10;
    cout << left << setw(12) << "Balance" <<  "$" << fixed << setprecision(2) << right << setw(9) <<sbalance << endl;
    cout << left << setw(12) <<"Check Fee" << "$"  <<right << setw(9) << numcheck << endl;
    cout << left << setw(12) <<"Monthly Fee" << "$"  << right << setw(9) << monthly << endl;
    cout << left << setw(12) <<"Low Balance" << "$"  <<right << setw(9) << low << endl;
    cout << left << setw(12) <<"New Balance" << "$"  <<right << setw(9) << nbalance;
     }else if(choice=='4'){
         string name1,name2,name3;
    float time1,time2,time3;
    //Initialize or input i.e. set variable values
cout<<"Race Ranking Program\n";
cout<<"Input 3 Runners\n";
cout<<"Their names, then their times\n";
cin>>name1>>time1;
cin>>name2>>time2;
cin>>name3>>time3;
if (time1 > time2 && time2 > time3){
  cout<<name3<<"\t"<<setw(3)<<time3<<endl;
  cout<<name2<<"\t"<<setw(3)<<time2<<endl;
  cout<<name1<<"\t"<<setw(3)<<time1; 
}
else if (time2 > time1 && time1 > time3){
  cout<<name3<<"\t"<<setw(3)<<time3<<endl;
  cout<<name1<<"\t"<<setw(3)<<time1<<endl;
  cout<<name2<<"\t"<<setw(3)<<time2; 
}
else if (time3 > time1 && time1 > time2){
  cout<<name2<<"\t"<<setw(3)<<time2<<endl;
  cout<<name1<<"\t"<<setw(3)<<time1<<endl;
  cout<<name3<<"\t"<<setw(3)<<time3; 
}
else if (time1 > time3 && time3 > time2){
  cout<<name2<<"\t"<<setw(3)<<time2<<endl;
  cout<<name3<<"\t"<<setw(3)<<time3<<endl;
  cout<<name1<<"\t"<<setw(3)<<time1; 
}
else if (time3 > time2 && time2 > time1){
  cout<<name1<<"\t"<<setw(3)<<time1<<endl;
  cout<<name2<<"\t"<<setw(3)<<time2<<endl;
  cout<<name3<<"\t"<<setw(3)<<time3; 
}
else if (time2 > time3 && time3 > time1){
  cout<<name1<<"\t"<<setw(3)<<time1<<endl;
  cout<<name3<<"\t"<<setw(3)<<time3<<endl;
  cout<<name2<<"\t"<<setw(3)<<time2; 
}
     }else if(choice=='5'){
  //Declare Variables
    unsigned short hours;// hours used a month
    float price;// final price
    char package;// package selected
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cout << "ISP Bill" << endl;
    cout << "Input Package and Hours" << endl;
    cin >> package;
    cin >> hours;
    
    //Display the outputs
switch (package){
    case'A':
    if (hours <= 10){
        price = 9.95;
        cout << "Bill = $" << setw(6) << price;
    }
    else {
    price = (hours - 10) * 2 + 9.95f;
    cout << "Bill = $" << setw(6) << price;
    }
    break;
    
    case'B':
        if (hours <= 20){
        price = 14.95;
        cout << "Bill = $" << setw(6) << price;
         }
        else {
        price = (hours - 20) * 1 + 14.95f;
         cout << "Bill = $" << setw(6) << price;
         }
    break;
    case'C':
    {
        price = 19.95;
        cout << "Bill = $" << setw(6) << price;
         }
    break;
    default: cout << "invalid number" << endl;
    
}
     }else if(choice=='6'){
         char one, two;//players
    //Initialize or input i.e. set variable values
    cout << "Rock Paper Scissors Game\n" ;
    cout << "Input Player 1 and Player 2 Choices\n" ;
    cin >> one;
    cin >> two;
    if (one == 'R' || one == 'r'){
        if (two == 'R' || two == 'r')
        cout << "Nobody wins.";
        else if (two == 'S' || two == 's')
            cout << "Rock breaks scissors.";
        else if (two == 'P' || two == 'p')
        cout << "Paper covers rock.";
    }
    if (one == 'P' || one == 'p'){
        if (two == 'R' || two == 'r')
        cout << "Paper covers rock.";
        else if (two == 'S' || two == 's')
            cout << "Scissors cuts paper.";
        else if (two == 'P' || two == 'p')
        cout << "Nobody wins.";
    }
    if (one == 'S' || one == 's'){
        if (two == 'R' || two == 'r')
        cout << "Rock breaks scissors.";
        else if (two == 'S' || two == 's')
            cout << "Nobody wins.";
        else if (two == 'P' || two == 'p')
        cout << "Scissors cuts paper.";
    }
     }else if(choice=='7'){
          unsigned short intial, thousand, hundred, ten, one;// numbersconversion
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cout << "Arabic to Roman numeral conversion." << endl;
    cout << "Input the integer to convert." << endl;
    cin >> intial;
    thousand = (intial / 1000) % 10;
    hundred =  (intial / 100) % 10;
    ten = (intial / 10) % 10;
    one = intial % 10;
    if (intial > 999 && intial < 2999){
        cout << intial << " is equal to ";
    if (thousand == 3) 
    cout << "MMM";
    else if (thousand == 2) 
    cout << "MM";
    else if (thousand == 1) 
    cout << "M";
    if (hundred == 9)
    cout << "CM";
    else if (hundred == 8)
    cout << "CCM";
    else if (hundred == 7)
    cout << "DCC";
    else if (hundred == 6)
    cout << "DC";
    else if (hundred == 5)
    cout << "D";
    else if (hundred == 4)
    cout << "CD";
    else if (hundred == 3)
    cout << "CCD";
    else if (hundred == 2)
    cout << "CC";
    else if (hundred == 1)
    cout << "C";
    if (ten == 9)
    cout << "XC";
    else if (ten == 8)
    cout << "XXC";
    else if (ten == 7)
    cout << "LXX";
    else if (ten == 6)
    cout << "LX";
    else if (ten == 5)
    cout << "L";
    else if (ten == 4)
    cout << "XL";
    else if (ten == 3)
    cout << "XXL";
    else if (ten == 2)
    cout << "XX";
    else if (ten == 1)
    cout << "X";
    if (one == 9)
    cout << "Ix";
    else if (one == 8)
    cout << "VIII";
    else if (one == 7)
    cout << "VII";
    else if (one == 6)
    cout << "VI";
    else if (one == 5)
    cout << "V";
    else if (one == 4)
    cout << "IV";
    else if (one == 3)
    cout << "IIV";
    else if (one == 2)
    cout << "IIIV";
    else if (one == 1)
    cout << "I";
    }
    else 
    cout << intial << " is Out of Range!";
    //Display the outputs
     }else if(choice=='8'){
        string sign1, sign2;
    //Initialize or input i.e. set variable values
    cout << "Horoscope Program which examines compatible signs." << endl;
    cout << "Input 2 signs." << endl;
    cin >> sign1;
    cin >> sign2;  
    
    if ( (sign1 == "Aries" && sign2 == "Leo") || (sign1 =="Aries" && sign2 == "Saggittarious") )
    cout << sign1 << " and " << sign2 << " are compatible Fire signs."; 
    else if ( (sign1 == "Leo" && sign2 == "Aries") || (sign1 =="Leo" && sign2 == "Saggittarious") )
    cout << sign1 << " and " << sign2 << " are compatible Fire signs."; 
    else if ( (sign1 == "Saggittarious" && sign2 == "Leo") || (sign1 =="Saggittarious" && sign2 == "Aries") )
    cout << sign1 << " and " << sign2 << " are compatible Fire signs.";  
    else if ( (sign1 == "Saggittarious" && sign2 == "Saggittarious") || (sign1 =="Aries" && sign2 == "Aries") )
    cout << sign1 << " and " << sign2 << " are compatible Fire signs.";  
    else if (sign1 == "Leo" && sign2 == "Leo")
    cout << sign1 << " and " << sign2 << " are compatible Fire signs.";
     
     else if ( (sign1 == "Taurus" && sign2 == "Virgo") || (sign1 =="Taurus" && sign2 == "Capricorn") )
    cout << sign1 << " and " << sign2 << " are compatible Earth signs."; 
    else if ( (sign1 == "Virgo" && sign2 == "Taurus") || (sign1 =="Virgo" && sign2 == "Capricorn") )
    cout << sign1 << " and " << sign2 << " are compatible Earth signs."; 
    else if ( (sign1 == "Capricorn" && sign2 == "Taurus") || (sign1 =="Capricorn" && sign2 == "Virgo") )
    cout << sign1 << " and " << sign2 << " are compatible Earth signs.";  
    else if ( (sign1 == "Capricorn" && sign2 == "Capricorn") || (sign1 =="Taurus" && sign2 == "Taurus") )
    cout << sign1 << " and " << sign2 << " are compatible Earth signs.";  
    else if (sign1 == "Virgo" && sign2 == "Virgo")
    cout << sign1 << " and " << sign2 << " are compatible Earth signs.";
   
    else if ( (sign1 == "Cancer" && sign2 == "Scorpio") || (sign1 =="Cancer" && sign2 == "Pisces") )
    cout << sign1 << " and " << sign2 << " are compatible Water signs."; 
    else if ( (sign1 == "Scorpio" && sign2 == "Cancer") || (sign1 =="Scorpio" && sign2 == "Pisces") )
    cout << sign1 << " and " << sign2 << " are compatible Water signs."; 
    else if ( (sign1 == "Pisces" && sign2 == "Cancer") || (sign1 =="Pisces" && sign2 == "Virgo") )
    cout << sign1 << " and " << sign2 << " are compatible Water signs.";  
    else if ( (sign1 == "Scorpio" && sign2 == "Scorpio") || (sign1 =="Pisces" && sign2 == "Pisces") )
    cout << sign1 << " and " << sign2 << " are compatible Water signs.";  
    else if (sign1 == "Cancer" && sign2 == "Cancer")
    cout << sign1 << " and " << sign2 << " are compatible Water signs.";
    else
    cout <<  sign1 << " and " << sign2 << " are not compatible signs.";

    
     }
    //Clean Up
    
    //Exit stage right!
    return 0;
}