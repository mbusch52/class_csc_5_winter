/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    float tempf,tempc,dvconst;
    //Declare Variables
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
cout<<"Temperature Converter\n";
cout<<"Input Degrees Fahrenheit\n";
cin>>tempf;
cout<<fixed<<setprecision(1);
dvconst=(tempf-32)*5;
tempc=dvconst/9;
cout<<tempf<<" Degrees Fahrenheit = "<<tempc<<" Degrees Centigrade";
    //Display the outputs

    //Exit stage right or left!
    return 0;
}