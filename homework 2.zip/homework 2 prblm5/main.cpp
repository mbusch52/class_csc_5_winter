/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
const float pi=4*atan(1);
const float cnvrad=pi/180.0f;
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float angle;
    int x;

    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cout<<"Calculate trig functions\n";
    cout<<"Input the angle in degrees.\n";
    cin>>angle;
    x=angle;
    cout<<fixed<<setprecision(4);
    cout<<"sin("<<x<<")"" = "<<sin(angle*cnvrad)<<endl;
    cout<<"cos("<<x<<")"" = "<<cos(angle*cnvrad)<<endl;
    cout<<"tan("<<x<<")"" = "<<tan(angle*cnvrad);

    //Display the outputs

    //Exit stage right or left!
    return 0;
}