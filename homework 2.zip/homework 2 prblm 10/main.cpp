/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    short num1, num2, num3, num4, num5, num6, num7, num8, num9, num10;// intial numbers
    short pnum1, pnum2, pnum3, pnum4, pnum5, pnum6, pnum7, pnum8, pnum9, pnum10;//place to store positive numbers
    short nnum1, nnum2, nnum3, nnum4, nnum5, nnum6, nnum7, nnum8, nnum9, nnum10;//place to store negative numbers
    short ttl, nttl, pttl;// totals of numbers
    //Initialize Variables
    cout << "Input 10 numbers, any order, positive or negative\n";
    cin >> num1;
    cin >> num2;
    cin >> num3;
    cin >> num4;
    cin >> num5;
    cin >> num6;
    cin >> num7;
    cin >> num8;
    cin >> num9;
    cin >> num10;
    if (num1 > 0)
    {
        pnum1 = num1;
        nnum1 = 0;
    }
    else
    {
        nnum1 = num1;
        pnum1 = 0;
    }
        if (num2 > 0)
    {
        pnum2 = num2;
        nnum2 = 0;
    }
    else
    {
        nnum2 = num2;
        pnum2 = 0;
    }
        if (num3 > 0)
    {
        pnum3 = num3;
        nnum3 = 0;
    }
    else
    {
        nnum3 = num3;
        pnum3 = 0;
    }
        if (num4 > 0)
    {
        pnum4 = num4;
        nnum4 = 0;
    }
    else
    {
        nnum4 = num4;
        pnum4 = 0;
    }
        if (num5  > 0)
    {
        pnum5 = num5;
        nnum5 = 0;
    }
    else
    {
        nnum5 = num5;
        pnum5 = 0;
    }
        if (num6 > 0)
    {
        pnum6 = num6;
        nnum6 = 0;
    }
    else
    {
        nnum6 = num6;
        pnum6 = 0;
    }
        if (num7 > 0)
    {
        pnum7 = num7;
        nnum7 = 0;
    }
    else
    {
        nnum7 = num7;
        pnum7 = 0;
    }
        if (num8 > 0)
    {
        pnum8 = num8;
        nnum8 = 0;
    }
    else
    {
        nnum8 = num8;
        pnum8 = 0;
    }
        if (num9 > 0)
    {
        pnum9 = num9;
        nnum9 = 0;
    }
    else
    {
        nnum9 = num9;
        pnum9 = 0;
    }
        if (num10 > 0)
    {
        pnum10 = num10;
        nnum10 = 0;
    }
    else
    {
        nnum10 = num10;
        pnum10 = 0;
    }
    ttl = num1 + num2 + num3 + num4 + num5 + num6 + num7 + num8 + num9 + num10;
    nttl = nnum1+ nnum2+ nnum3+ nnum4+ nnum5+ nnum6+ nnum7+ nnum8+ nnum9+ nnum10;
    pttl = pnum1+ pnum2+ pnum3+ pnum4+ pnum5+ pnum6+ pnum7+ pnum8+ pnum9+ pnum10;
    cout << "Negative sum =" << setw(4) << nttl << endl;
    cout << "Positive sum =" << setw(4) << pttl << endl;
    cout << "Total sum "<<setw(4)<<"=" << setw(4) << ttl ;
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    
    //Exit the Program - Cleanup
    return 0;
}