/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <string>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    string name1,name2,name3;
    float time1,time2,time3;
    //Initialize or input i.e. set variable values
cout<<"Race Ranking Program\n";
cout<<"Input 3 Runners\n";
cout<<"Their names, then their times\n";
cin>>name1>>time1;
cin>>name2>>time2;
cin>>name3>>time3;
if (time1 > time2 && time2 > time3){
  cout<<name3<<"\t"<<setw(3)<<time3<<endl;
  cout<<name2<<"\t"<<setw(3)<<time2<<endl;
  cout<<name1<<"\t"<<setw(3)<<time1; 
}
else if (time2 > time1 && time1 > time3){
  cout<<name3<<"\t"<<setw(3)<<time3<<endl;
  cout<<name1<<"\t"<<setw(3)<<time1<<endl;
  cout<<name2<<"\t"<<setw(3)<<time2; 
}
else if (time3 > time1 && time1 > time2){
  cout<<name2<<"\t"<<setw(3)<<time2<<endl;
  cout<<name1<<"\t"<<setw(3)<<time1<<endl;
  cout<<name3<<"\t"<<setw(3)<<time3; 
}
else if (time1 > time3 && time3 > time2){
  cout<<name2<<"\t"<<setw(3)<<time2<<endl;
  cout<<name3<<"\t"<<setw(3)<<time3<<endl;
  cout<<name1<<"\t"<<setw(3)<<time1; 
}
else if (time3 > time2 && time2 > time1){
  cout<<name1<<"\t"<<setw(3)<<time1<<endl;
  cout<<name2<<"\t"<<setw(3)<<time2<<endl;
  cout<<name3<<"\t"<<setw(3)<<time3; 
}
else if (time2 > time3 && time3 > time1){
  cout<<name1<<"\t"<<setw(3)<<time1<<endl;
  cout<<name3<<"\t"<<setw(3)<<time3<<endl;
  cout<<name2<<"\t"<<setw(3)<<time2; 
}
  return 0;
  
}
