/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <string>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string sign1, sign2;
    //Initialize or input i.e. set variable values
    cout << "Horoscope Program which examines compatible signs." << endl;
    cout << "Input 2 signs." << endl;
    cin >> sign1;
    cin >> sign2;  
    
    if ( (sign1 == "Aries" && sign2 == "Leo") || (sign1 =="Aries" && sign2 == "Saggittarious") )
    cout << sign1 << " and " << sign2 << " are compatible Fire signs."; 
    else if ( (sign1 == "Leo" && sign2 == "Aries") || (sign1 =="Leo" && sign2 == "Saggittarious") )
    cout << sign1 << " and " << sign2 << " are compatible Fire signs."; 
    else if ( (sign1 == "Saggittarious" && sign2 == "Leo") || (sign1 =="Saggittarious" && sign2 == "Aries") )
    cout << sign1 << " and " << sign2 << " are compatible Fire signs.";  
    else if ( (sign1 == "Saggittarious" && sign2 == "Saggittarious") || (sign1 =="Aries" && sign2 == "Aries") )
    cout << sign1 << " and " << sign2 << " are compatible Fire signs.";  
    else if (sign1 == "Leo" && sign2 == "Leo")
    cout << sign1 << " and " << sign2 << " are compatible Fire signs.";
     
     else if ( (sign1 == "Taurus" && sign2 == "Virgo") || (sign1 =="Taurus" && sign2 == "Capricorn") )
    cout << sign1 << " and " << sign2 << " are compatible Earth signs."; 
    else if ( (sign1 == "Virgo" && sign2 == "Taurus") || (sign1 =="Virgo" && sign2 == "Capricorn") )
    cout << sign1 << " and " << sign2 << " are compatible Earth signs."; 
    else if ( (sign1 == "Capricorn" && sign2 == "Taurus") || (sign1 =="Capricorn" && sign2 == "Virgo") )
    cout << sign1 << " and " << sign2 << " are compatible Earth signs.";  
    else if ( (sign1 == "Capricorn" && sign2 == "Capricorn") || (sign1 =="Taurus" && sign2 == "Taurus") )
    cout << sign1 << " and " << sign2 << " are compatible Earth signs.";  
    else if (sign1 == "Virgo" && sign2 == "Virgo")
    cout << sign1 << " and " << sign2 << " are compatible Earth signs.";
   
    else if ( (sign1 == "Cancer" && sign2 == "Scorpio") || (sign1 =="Cancer" && sign2 == "Pisces") )
    cout << sign1 << " and " << sign2 << " are compatible Water signs."; 
    else if ( (sign1 == "Scorpio" && sign2 == "Cancer") || (sign1 =="Scorpio" && sign2 == "Pisces") )
    cout << sign1 << " and " << sign2 << " are compatible Water signs."; 
    else if ( (sign1 == "Pisces" && sign2 == "Cancer") || (sign1 =="Pisces" && sign2 == "Virgo") )
    cout << sign1 << " and " << sign2 << " are compatible Water signs.";  
    else if ( (sign1 == "Scorpio" && sign2 == "Scorpio") || (sign1 =="Pisces" && sign2 == "Pisces") )
    cout << sign1 << " and " << sign2 << " are compatible Water signs.";  
    else if (sign1 == "Cancer" && sign2 == "Cancer")
    cout << sign1 << " and " << sign2 << " are compatible Water signs.";
    else
    cout <<  sign1 << " and " << sign2 << " are not compatible signs.";

    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}