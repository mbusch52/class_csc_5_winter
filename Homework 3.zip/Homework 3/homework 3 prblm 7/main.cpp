/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    unsigned short intial, thousand, hundred, ten, one;// numbersconversion
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cout << "Arabic to Roman numeral conversion." << endl;
    cout << "Input the integer to convert." << endl;
    cin >> intial;
    thousand = (intial / 1000) % 10;
    hundred =  (intial / 100) % 10;
    ten = (intial / 10) % 10;
    one = intial % 10;
    if (thousand == 3) 
    cout << "MMM";
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}
