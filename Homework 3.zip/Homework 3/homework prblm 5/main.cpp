/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    unsigned short hours;// hours used a month
    float price;// final price
    char package;// package selected
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cout << "ISP Bill" << endl;
    cout << "Input Package and Hours" << endl;
    cin >> package;
    cin >> hours;
    
    //Display the outputs
switch (package){
    case'A':
    if (hours <= 10){
        price = 9.95;
        cout << "Bill = $" << setw(6) << price;
    }
    else {
    price = (hours - 10) * 2 + 9.95f;
    cout << "Bill = $" << setw(6) << price;
    }
    break;
    
    case'B':
        if (hours <= 20){
        price = 14.95;
        cout << "Bill = $" << setw(6) << price;
         }
        else {
        price = (hours - 20) * 1 + 14.95f;
         cout << "Bill = $" << setw(6) << price;
         }
    break;
    case'C':
    {
        price = 19.95;
        cout << "Bill = $" << setw(6) << price;
         }
    break;
    default: cout << "invalid number" << endl;
    
}
    //Exit stage right or left!
    return 0;
}