/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    char numbook;
    unsigned short points;
    //Initialize or input i.e. set variable values
    cout<<"Book Worm Points\n";
    cout<<"Input the number of books purchased this month.\n";
    cin>>numbook;
    cout<<"Books purchased ="<< setw(3) << fixed << setprecision(0) <<numbook<<endl;
    if (numbook>=4){
        points = 60;
    }
    else if (numbook==3){
        points = 30;
    }
    else if (numbook==2){
        points = 15;
    }
    else if (numbook==1){
        points = 5;
    }
    else if (numbook<=0){
        points = 0;
    }
    else 
    cout << "you entered an incorrect number";
    cout<<"Points earned" << setw(4) <<"="<< setw(3) << fixed << setprecision(0) <<points;
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}