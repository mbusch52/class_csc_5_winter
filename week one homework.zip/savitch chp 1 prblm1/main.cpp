/* 
 * File:   main.cpp
 * Author: Busch, Michael
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    int numOne, numTwo;
    //Map Inputs to Outputs -> Process
    cout << "This program will take two numbers from the user " << endl;
    cout << "Then display the sum and product" << endl;
    cout << "Enter the first number" << endl;
    cin >> numOne;
    cout << "Enter the second number" << endl;
    cin >> numTwo;
    cout << "The sum of the two numbers is " << numOne + numTwo << endl;
    cout << "The product of the two numbers is " << numOne * numTwo << endl;
    cout << "This is the end of the program "; 
    //Display Inputs/Outputs

    //Exit the Program - Cleanup
    return 0;
}