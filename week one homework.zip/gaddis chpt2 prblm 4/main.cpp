/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream> 
#include <iomanip>//I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float tax,tip, ttl;
    //Initialize Variables
    tax = 88.67 * .0675;
    tip = (88.67 + tax) * .2;
    ttl = 88.67 + tip + tax;
    cout << "The total cost of your meal is " << fixed << setprecision(2) << ttl << "the tip was " << tip << "the tax was " << tax;
    
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    
    //Exit the Program - Cleanup
    return 0;
}