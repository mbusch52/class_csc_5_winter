/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    unsigned short quart, dime, nickel, ttl ;
    cout << "This program will take the number of quarters nickels and dimes" << endl;
    cout << "and tell you how much the total value is" << endl;
    cout << "enter how many quarters you have " << endl;
    cin >> quart;
    quart = quart * 25;
    cout << "enter how many dimes you have"<< endl;
    cin >> dime;
    dime = dime * 10;
    cout << "enter how many nickels you have"<< endl;
    cin >> nickel;
    nickel = nickel *5;
    ttl = quart + dime + nickel;
    cout << "The total amount of money is "<< ttl <<" cents." << endl;
    
    
    
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    
    //Exit the Program - Cleanup
    return 0;
}