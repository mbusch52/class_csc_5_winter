/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 4, 2021, 10:50 AM
 * Purpose:  CPP Template 
 *           To be copied for each Assignment Problem
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    float ttltax;
    //Initialize Variables
    ttltax = 95 *.06;
    
    //Map Inputs to Outputs -> Process
    cout << "The total sales tax on $95 dollars is " << ttltax;
    
    //Display Inputs/Outputs
    
    //Exit the Program - Cleanup
    return 0;
}